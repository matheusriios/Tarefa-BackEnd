import {MigrationInterface, QueryRunner} from "typeorm";

export class Tarefa1554683211768 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
    }

}
