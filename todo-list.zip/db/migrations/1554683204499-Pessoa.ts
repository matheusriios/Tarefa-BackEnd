import {MigrationInterface, QueryRunner} from "typeorm";

export class Pessoa1554683204499 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
    }

}
